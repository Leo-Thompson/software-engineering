﻿
namespace test1
{
    partial class menuPanel
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menuPanel));
            this.spellLbl1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.rangeBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.levelBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.compBox = new System.Windows.Forms.TextBox();
            this.castingTimeBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.frameChange = new System.Windows.Forms.Timer(this.components);
            this.mediaBox = new System.Windows.Forms.PictureBox();
            this.playBtn = new System.Windows.Forms.Button();
            this.durationBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.schoolBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.spellLbl2 = new System.Windows.Forms.Label();
            this.splLbl3 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.invertBtn = new System.Windows.Forms.Button();
            this.reverseBtn = new System.Windows.Forms.Button();
            this.pauseBtn = new System.Windows.Forms.Button();
            this.BWbtn = new System.Windows.Forms.Button();
            this.mediaReturnBtn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.menuSpellBtn = new System.Windows.Forms.Button();
            this.menuCharBtn = new System.Windows.Forms.Button();
            this.menuSettingBtn = new System.Windows.Forms.Button();
            this.spellPanel = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.menuMediaBtn = new System.Windows.Forms.Button();
            this.menuExitBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuAdminBtn = new System.Windows.Forms.Button();
            this.mediaPanel = new System.Windows.Forms.Panel();
            this.settingsPanel = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.darkMode = new System.Windows.Forms.RadioButton();
            this.lightMode = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.adminCheckPanel = new System.Windows.Forms.Panel();
            this.adminCheckReturnBtn = new System.Windows.Forms.Button();
            this.entrPswrdBtn = new System.Windows.Forms.Button();
            this.adminPswrdInput = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.adminPanel = new System.Windows.Forms.Panel();
            this.saveRawBtn = new System.Windows.Forms.Button();
            this.updatePasswordBtn = new System.Windows.Forms.Button();
            this.passwordVisibleBtn = new System.Windows.Forms.Button();
            this.adminPasswordTxtBX = new System.Windows.Forms.TextBox();
            this.adminLbl2 = new System.Windows.Forms.Label();
            this.adminLbl3 = new System.Windows.Forms.Label();
            this.rawDataTxtBx = new System.Windows.Forms.TextBox();
            this.comitFileNameBtn = new System.Windows.Forms.Button();
            this.fileNameTxtBx = new System.Windows.Forms.TextBox();
            this.adminLbl1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.adminReturn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.mediaBox)).BeginInit();
            this.spellPanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.mediaPanel.SuspendLayout();
            this.settingsPanel.SuspendLayout();
            this.adminCheckPanel.SuspendLayout();
            this.adminPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // spellLbl1
            // 
            this.spellLbl1.AutoSize = true;
            this.spellLbl1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.spellLbl1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.spellLbl1.Location = new System.Drawing.Point(5, 10);
            this.spellLbl1.Name = "spellLbl1";
            this.spellLbl1.Size = new System.Drawing.Size(115, 21);
            this.spellLbl1.TabIndex = 0;
            this.spellLbl1.Text = "Select Spell";
            this.spellLbl1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.spellLbl1.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.spellLbl1.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(5, 38);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(216, 33);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.TextUpdate += new System.EventHandler(this.listItem);
            this.comboBox1.TextChanged += new System.EventHandler(this.listItem);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(5, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label2.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(239, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Range";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label3.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label3.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // nameBox
            // 
            this.nameBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.nameBox.Location = new System.Drawing.Point(6, 225);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(215, 31);
            this.nameBox.TabIndex = 4;
            // 
            // rangeBox
            // 
            this.rangeBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.rangeBox.Location = new System.Drawing.Point(239, 225);
            this.rangeBox.Name = "rangeBox";
            this.rangeBox.Size = new System.Drawing.Size(216, 31);
            this.rangeBox.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(5, 383);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "Level";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label5.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label5.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // levelBox
            // 
            this.levelBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.levelBox.Location = new System.Drawing.Point(5, 411);
            this.levelBox.Name = "levelBox";
            this.levelBox.Size = new System.Drawing.Size(214, 31);
            this.levelBox.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(239, 321);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 21);
            this.label6.TabIndex = 10;
            this.label6.Text = "Component(s)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label6.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label6.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // compBox
            // 
            this.compBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.compBox.Location = new System.Drawing.Point(239, 349);
            this.compBox.Name = "compBox";
            this.compBox.Size = new System.Drawing.Size(214, 31);
            this.compBox.TabIndex = 11;
            // 
            // castingTimeBox
            // 
            this.castingTimeBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.castingTimeBox.Location = new System.Drawing.Point(5, 349);
            this.castingTimeBox.Name = "castingTimeBox";
            this.castingTimeBox.Size = new System.Drawing.Size(214, 31);
            this.castingTimeBox.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(5, 321);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 21);
            this.label9.TabIndex = 15;
            this.label9.Text = "Casting Time";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label9.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label9.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // frameChange
            // 
            this.frameChange.Interval = 50;
            this.frameChange.Tick += new System.EventHandler(this.changeFrame);
            // 
            // mediaBox
            // 
            this.mediaBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.mediaBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("mediaBox.InitialImage")));
            this.mediaBox.Location = new System.Drawing.Point(0, 161);
            this.mediaBox.Name = "mediaBox";
            this.mediaBox.Size = new System.Drawing.Size(484, 315);
            this.mediaBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mediaBox.TabIndex = 44;
            this.mediaBox.TabStop = false;
            this.mediaBox.Visible = false;
            this.mediaBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // playBtn
            // 
            this.playBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.playBtn.FlatAppearance.BorderSize = 0;
            this.playBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.playBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.playBtn.Location = new System.Drawing.Point(3, 73);
            this.playBtn.Name = "playBtn";
            this.playBtn.Size = new System.Drawing.Size(107, 66);
            this.playBtn.TabIndex = 45;
            this.playBtn.Text = "Play ";
            this.playBtn.UseVisualStyleBackColor = false;
            this.playBtn.Click += new System.EventHandler(this.startMeme);
            // 
            // durationBox
            // 
            this.durationBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.durationBox.Location = new System.Drawing.Point(239, 287);
            this.durationBox.Name = "durationBox";
            this.durationBox.Size = new System.Drawing.Size(214, 31);
            this.durationBox.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(239, 259);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(86, 21);
            this.label21.TabIndex = 47;
            this.label21.Text = "Duration";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label21.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label21.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // schoolBox
            // 
            this.schoolBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.schoolBox.Location = new System.Drawing.Point(5, 287);
            this.schoolBox.Name = "schoolBox";
            this.schoolBox.Size = new System.Drawing.Size(214, 31);
            this.schoolBox.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(5, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 21);
            this.label4.TabIndex = 48;
            this.label4.Text = "School";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label4.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label4.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(6, 127);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(215, 33);
            this.comboBox2.TabIndex = 50;
            this.comboBox2.TextUpdate += new System.EventHandler(this.alterKey);
            this.comboBox2.TextChanged += new System.EventHandler(this.alterKey);
            // 
            // spellLbl2
            // 
            this.spellLbl2.AutoSize = true;
            this.spellLbl2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.spellLbl2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.spellLbl2.Location = new System.Drawing.Point(6, 96);
            this.spellLbl2.Name = "spellLbl2";
            this.spellLbl2.Size = new System.Drawing.Size(84, 21);
            this.spellLbl2.TabIndex = 51;
            this.spellLbl2.Text = "Filter By";
            this.spellLbl2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // splLbl3
            // 
            this.splLbl3.AutoSize = true;
            this.splLbl3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.splLbl3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.splLbl3.Location = new System.Drawing.Point(240, 96);
            this.splLbl3.Name = "splLbl3";
            this.splLbl3.Size = new System.Drawing.Size(44, 21);
            this.splLbl3.TabIndex = 52;
            this.splLbl3.Text = "Key";
            this.splLbl3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(240, 127);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(215, 33);
            this.comboBox3.TabIndex = 53;
            this.comboBox3.TextUpdate += new System.EventHandler(this.alterKey);
            this.comboBox3.TextChanged += new System.EventHandler(this.alterKey);
            // 
            // invertBtn
            // 
            this.invertBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.invertBtn.FlatAppearance.BorderSize = 0;
            this.invertBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invertBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.invertBtn.Location = new System.Drawing.Point(247, 109);
            this.invertBtn.Name = "invertBtn";
            this.invertBtn.Size = new System.Drawing.Size(125, 30);
            this.invertBtn.TabIndex = 54;
            this.invertBtn.Text = "Invert";
            this.invertBtn.UseVisualStyleBackColor = false;
            this.invertBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // reverseBtn
            // 
            this.reverseBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.reverseBtn.FlatAppearance.BorderSize = 0;
            this.reverseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reverseBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.reverseBtn.Location = new System.Drawing.Point(116, 109);
            this.reverseBtn.Name = "reverseBtn";
            this.reverseBtn.Size = new System.Drawing.Size(125, 30);
            this.reverseBtn.TabIndex = 55;
            this.reverseBtn.Text = "Reverse";
            this.reverseBtn.UseVisualStyleBackColor = false;
            this.reverseBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // pauseBtn
            // 
            this.pauseBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pauseBtn.FlatAppearance.BorderSize = 0;
            this.pauseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pauseBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pauseBtn.Location = new System.Drawing.Point(116, 73);
            this.pauseBtn.Name = "pauseBtn";
            this.pauseBtn.Size = new System.Drawing.Size(125, 30);
            this.pauseBtn.TabIndex = 56;
            this.pauseBtn.Text = "Pause";
            this.pauseBtn.UseVisualStyleBackColor = false;
            this.pauseBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // BWbtn
            // 
            this.BWbtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BWbtn.FlatAppearance.BorderSize = 0;
            this.BWbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BWbtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BWbtn.Location = new System.Drawing.Point(247, 73);
            this.BWbtn.Name = "BWbtn";
            this.BWbtn.Size = new System.Drawing.Size(125, 30);
            this.BWbtn.TabIndex = 57;
            this.BWbtn.Text = "Black/White";
            this.BWbtn.UseVisualStyleBackColor = false;
            this.BWbtn.Click += new System.EventHandler(this.button5_Click);
            // 
            // mediaReturnBtn
            // 
            this.mediaReturnBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.mediaReturnBtn.FlatAppearance.BorderSize = 0;
            this.mediaReturnBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mediaReturnBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.mediaReturnBtn.Location = new System.Drawing.Point(378, 73);
            this.mediaReturnBtn.Name = "mediaReturnBtn";
            this.mediaReturnBtn.Size = new System.Drawing.Size(103, 66);
            this.mediaReturnBtn.TabIndex = 58;
            this.mediaReturnBtn.Text = "Return";
            this.mediaReturnBtn.UseVisualStyleBackColor = false;
            this.mediaReturnBtn.Click += new System.EventHandler(this.button13_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(104, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(246, 48);
            this.label10.TabIndex = 61;
            this.label10.Text = "DndD Wizard";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuSpellBtn
            // 
            this.menuSpellBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuSpellBtn.FlatAppearance.BorderSize = 0;
            this.menuSpellBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuSpellBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuSpellBtn.Location = new System.Drawing.Point(110, 170);
            this.menuSpellBtn.Name = "menuSpellBtn";
            this.menuSpellBtn.Size = new System.Drawing.Size(240, 47);
            this.menuSpellBtn.TabIndex = 62;
            this.menuSpellBtn.Text = "Spell Compendium";
            this.menuSpellBtn.UseVisualStyleBackColor = false;
            this.menuSpellBtn.Click += new System.EventHandler(this.button8_Click);
            this.menuSpellBtn.MouseEnter += new System.EventHandler(this.menuHighlight);
            this.menuSpellBtn.MouseLeave += new System.EventHandler(this.revertHighlight);
            this.menuSpellBtn.MouseHover += new System.EventHandler(this.menuHighlight);
            // 
            // menuCharBtn
            // 
            this.menuCharBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuCharBtn.FlatAppearance.BorderSize = 0;
            this.menuCharBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuCharBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuCharBtn.Location = new System.Drawing.Point(110, 223);
            this.menuCharBtn.Name = "menuCharBtn";
            this.menuCharBtn.Size = new System.Drawing.Size(240, 47);
            this.menuCharBtn.TabIndex = 63;
            this.menuCharBtn.Text = "Character List";
            this.menuCharBtn.UseVisualStyleBackColor = false;
            this.menuCharBtn.Click += new System.EventHandler(this.button9_Click);
            this.menuCharBtn.MouseEnter += new System.EventHandler(this.menuHighlight);
            this.menuCharBtn.MouseLeave += new System.EventHandler(this.revertHighlight);
            this.menuCharBtn.MouseHover += new System.EventHandler(this.menuHighlight);
            // 
            // menuSettingBtn
            // 
            this.menuSettingBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuSettingBtn.FlatAppearance.BorderSize = 0;
            this.menuSettingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuSettingBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuSettingBtn.Location = new System.Drawing.Point(110, 275);
            this.menuSettingBtn.Name = "menuSettingBtn";
            this.menuSettingBtn.Size = new System.Drawing.Size(240, 47);
            this.menuSettingBtn.TabIndex = 64;
            this.menuSettingBtn.Text = "Settings";
            this.menuSettingBtn.UseVisualStyleBackColor = false;
            this.menuSettingBtn.Click += new System.EventHandler(this.button10_Click);
            this.menuSettingBtn.MouseEnter += new System.EventHandler(this.menuHighlight);
            this.menuSettingBtn.MouseLeave += new System.EventHandler(this.revertHighlight);
            this.menuSettingBtn.MouseHover += new System.EventHandler(this.menuHighlight);
            // 
            // spellPanel
            // 
            this.spellPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(230)))));
            this.spellPanel.Controls.Add(this.button13);
            this.spellPanel.Controls.Add(this.spellLbl1);
            this.spellPanel.Controls.Add(this.comboBox1);
            this.spellPanel.Controls.Add(this.label2);
            this.spellPanel.Controls.Add(this.label3);
            this.spellPanel.Controls.Add(this.nameBox);
            this.spellPanel.Controls.Add(this.rangeBox);
            this.spellPanel.Controls.Add(this.label5);
            this.spellPanel.Controls.Add(this.levelBox);
            this.spellPanel.Controls.Add(this.label6);
            this.spellPanel.Controls.Add(this.compBox);
            this.spellPanel.Controls.Add(this.label9);
            this.spellPanel.Controls.Add(this.comboBox3);
            this.spellPanel.Controls.Add(this.castingTimeBox);
            this.spellPanel.Controls.Add(this.splLbl3);
            this.spellPanel.Controls.Add(this.durationBox);
            this.spellPanel.Controls.Add(this.spellLbl2);
            this.spellPanel.Controls.Add(this.label21);
            this.spellPanel.Controls.Add(this.comboBox2);
            this.spellPanel.Controls.Add(this.label4);
            this.spellPanel.Controls.Add(this.schoolBox);
            this.spellPanel.Location = new System.Drawing.Point(1496, 9);
            this.spellPanel.Name = "spellPanel";
            this.spellPanel.Size = new System.Drawing.Size(484, 606);
            this.spellPanel.TabIndex = 65;
            this.spellPanel.MouseHover += new System.EventHandler(this.menuHighlight);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button13.Location = new System.Drawing.Point(378, 10);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(103, 47);
            this.button13.TabIndex = 68;
            this.button13.Text = "Return";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // menuMediaBtn
            // 
            this.menuMediaBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuMediaBtn.FlatAppearance.BorderSize = 0;
            this.menuMediaBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuMediaBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuMediaBtn.Location = new System.Drawing.Point(110, 328);
            this.menuMediaBtn.Name = "menuMediaBtn";
            this.menuMediaBtn.Size = new System.Drawing.Size(240, 47);
            this.menuMediaBtn.TabIndex = 66;
            this.menuMediaBtn.Text = "Media Player";
            this.menuMediaBtn.UseVisualStyleBackColor = false;
            this.menuMediaBtn.Click += new System.EventHandler(this.button11_Click);
            this.menuMediaBtn.MouseEnter += new System.EventHandler(this.menuHighlight);
            this.menuMediaBtn.MouseLeave += new System.EventHandler(this.revertHighlight);
            this.menuMediaBtn.MouseHover += new System.EventHandler(this.menuHighlight);
            // 
            // menuExitBtn
            // 
            this.menuExitBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuExitBtn.FlatAppearance.BorderSize = 0;
            this.menuExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuExitBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuExitBtn.Location = new System.Drawing.Point(110, 434);
            this.menuExitBtn.Name = "menuExitBtn";
            this.menuExitBtn.Size = new System.Drawing.Size(240, 47);
            this.menuExitBtn.TabIndex = 67;
            this.menuExitBtn.Text = "Exit";
            this.menuExitBtn.UseVisualStyleBackColor = false;
            this.menuExitBtn.Click += new System.EventHandler(this.button12_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.panel2.Controls.Add(this.menuAdminBtn);
            this.panel2.Controls.Add(this.menuExitBtn);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.menuMediaBtn);
            this.panel2.Controls.Add(this.menuSpellBtn);
            this.panel2.Controls.Add(this.menuCharBtn);
            this.panel2.Controls.Add(this.menuSettingBtn);
            this.panel2.Location = new System.Drawing.Point(2, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(484, 604);
            this.panel2.TabIndex = 68;
            // 
            // menuAdminBtn
            // 
            this.menuAdminBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuAdminBtn.FlatAppearance.BorderSize = 0;
            this.menuAdminBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuAdminBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuAdminBtn.Location = new System.Drawing.Point(110, 381);
            this.menuAdminBtn.Name = "menuAdminBtn";
            this.menuAdminBtn.Size = new System.Drawing.Size(240, 47);
            this.menuAdminBtn.TabIndex = 68;
            this.menuAdminBtn.Text = "Admin";
            this.menuAdminBtn.UseVisualStyleBackColor = false;
            this.menuAdminBtn.Click += new System.EventHandler(this.button7_Click);
            // 
            // mediaPanel
            // 
            this.mediaPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.mediaPanel.Controls.Add(this.playBtn);
            this.mediaPanel.Controls.Add(this.mediaBox);
            this.mediaPanel.Controls.Add(this.invertBtn);
            this.mediaPanel.Controls.Add(this.mediaReturnBtn);
            this.mediaPanel.Controls.Add(this.reverseBtn);
            this.mediaPanel.Controls.Add(this.BWbtn);
            this.mediaPanel.Controls.Add(this.pauseBtn);
            this.mediaPanel.Location = new System.Drawing.Point(1006, 9);
            this.mediaPanel.Name = "mediaPanel";
            this.mediaPanel.Size = new System.Drawing.Size(484, 609);
            this.mediaPanel.TabIndex = 69;
            // 
            // settingsPanel
            // 
            this.settingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.settingsPanel.Controls.Add(this.button15);
            this.settingsPanel.Controls.Add(this.darkMode);
            this.settingsPanel.Controls.Add(this.lightMode);
            this.settingsPanel.Controls.Add(this.label11);
            this.settingsPanel.Location = new System.Drawing.Point(503, 565);
            this.settingsPanel.Name = "settingsPanel";
            this.settingsPanel.Size = new System.Drawing.Size(484, 620);
            this.settingsPanel.TabIndex = 70;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button15.Location = new System.Drawing.Point(378, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(103, 48);
            this.button15.TabIndex = 69;
            this.button15.Text = "Return";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button13_Click);
            // 
            // darkMode
            // 
            this.darkMode.AutoSize = true;
            this.darkMode.FlatAppearance.BorderSize = 0;
            this.darkMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.darkMode.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.darkMode.Location = new System.Drawing.Point(12, 123);
            this.darkMode.Name = "darkMode";
            this.darkMode.Size = new System.Drawing.Size(139, 27);
            this.darkMode.TabIndex = 2;
            this.darkMode.Text = "Dark Mode";
            this.darkMode.UseVisualStyleBackColor = true;
            this.darkMode.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // lightMode
            // 
            this.lightMode.AutoSize = true;
            this.lightMode.Checked = true;
            this.lightMode.FlatAppearance.BorderSize = 0;
            this.lightMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lightMode.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lightMode.Location = new System.Drawing.Point(12, 88);
            this.lightMode.Name = "lightMode";
            this.lightMode.Size = new System.Drawing.Size(141, 27);
            this.lightMode.TabIndex = 1;
            this.lightMode.TabStop = true;
            this.lightMode.Text = "Light Mode";
            this.lightMode.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(179, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 28);
            this.label11.TabIndex = 0;
            this.label11.Text = "Settings";
            // 
            // adminCheckPanel
            // 
            this.adminCheckPanel.Controls.Add(this.adminCheckReturnBtn);
            this.adminCheckPanel.Controls.Add(this.entrPswrdBtn);
            this.adminCheckPanel.Controls.Add(this.adminPswrdInput);
            this.adminCheckPanel.Controls.Add(this.label12);
            this.adminCheckPanel.Location = new System.Drawing.Point(1039, 644);
            this.adminCheckPanel.Name = "adminCheckPanel";
            this.adminCheckPanel.Size = new System.Drawing.Size(300, 130);
            this.adminCheckPanel.TabIndex = 71;
            // 
            // adminCheckReturnBtn
            // 
            this.adminCheckReturnBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.adminCheckReturnBtn.FlatAppearance.BorderSize = 0;
            this.adminCheckReturnBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminCheckReturnBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.adminCheckReturnBtn.Location = new System.Drawing.Point(210, 3);
            this.adminCheckReturnBtn.Name = "adminCheckReturnBtn";
            this.adminCheckReturnBtn.Size = new System.Drawing.Size(87, 31);
            this.adminCheckReturnBtn.TabIndex = 71;
            this.adminCheckReturnBtn.Text = "Return";
            this.adminCheckReturnBtn.UseVisualStyleBackColor = false;
            this.adminCheckReturnBtn.Click += new System.EventHandler(this.button13_Click);
            // 
            // entrPswrdBtn
            // 
            this.entrPswrdBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.entrPswrdBtn.FlatAppearance.BorderSize = 0;
            this.entrPswrdBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.entrPswrdBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.entrPswrdBtn.Location = new System.Drawing.Point(198, 70);
            this.entrPswrdBtn.Name = "entrPswrdBtn";
            this.entrPswrdBtn.Size = new System.Drawing.Size(99, 31);
            this.entrPswrdBtn.TabIndex = 70;
            this.entrPswrdBtn.Text = "Confirm";
            this.entrPswrdBtn.UseVisualStyleBackColor = false;
            this.entrPswrdBtn.Click += new System.EventHandler(this.button16_Click);
            // 
            // adminPswrdInput
            // 
            this.adminPswrdInput.Location = new System.Drawing.Point(3, 70);
            this.adminPswrdInput.Name = "adminPswrdInput";
            this.adminPswrdInput.Size = new System.Drawing.Size(189, 31);
            this.adminPswrdInput.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(190, 25);
            this.label12.TabIndex = 0;
            this.label12.Text = "Input Admin Passcode";
            // 
            // adminPanel
            // 
            this.adminPanel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.adminPanel.Controls.Add(this.label1);
            this.adminPanel.Controls.Add(this.saveRawBtn);
            this.adminPanel.Controls.Add(this.updatePasswordBtn);
            this.adminPanel.Controls.Add(this.passwordVisibleBtn);
            this.adminPanel.Controls.Add(this.adminPasswordTxtBX);
            this.adminPanel.Controls.Add(this.adminLbl2);
            this.adminPanel.Controls.Add(this.adminLbl3);
            this.adminPanel.Controls.Add(this.rawDataTxtBx);
            this.adminPanel.Controls.Add(this.comitFileNameBtn);
            this.adminPanel.Controls.Add(this.fileNameTxtBx);
            this.adminPanel.Controls.Add(this.adminLbl1);
            this.adminPanel.Controls.Add(this.label13);
            this.adminPanel.Controls.Add(this.adminReturn);
            this.adminPanel.Location = new System.Drawing.Point(506, 9);
            this.adminPanel.Name = "adminPanel";
            this.adminPanel.Size = new System.Drawing.Size(484, 630);
            this.adminPanel.TabIndex = 71;
            // 
            // saveRawBtn
            // 
            this.saveRawBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.saveRawBtn.FlatAppearance.BorderSize = 0;
            this.saveRawBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveRawBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.saveRawBtn.Location = new System.Drawing.Point(339, 272);
            this.saveRawBtn.Name = "saveRawBtn";
            this.saveRawBtn.Size = new System.Drawing.Size(103, 40);
            this.saveRawBtn.TabIndex = 80;
            this.saveRawBtn.Text = "Save";
            this.saveRawBtn.UseVisualStyleBackColor = false;
            this.saveRawBtn.Click += new System.EventHandler(this.button21_Click);
            // 
            // updatePasswordBtn
            // 
            this.updatePasswordBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.updatePasswordBtn.FlatAppearance.BorderSize = 0;
            this.updatePasswordBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updatePasswordBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.updatePasswordBtn.Location = new System.Drawing.Point(339, 169);
            this.updatePasswordBtn.Name = "updatePasswordBtn";
            this.updatePasswordBtn.Size = new System.Drawing.Size(103, 31);
            this.updatePasswordBtn.TabIndex = 79;
            this.updatePasswordBtn.Text = "Update";
            this.updatePasswordBtn.UseVisualStyleBackColor = false;
            this.updatePasswordBtn.Click += new System.EventHandler(this.button20_Click);
            // 
            // passwordVisibleBtn
            // 
            this.passwordVisibleBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.passwordVisibleBtn.FlatAppearance.BorderSize = 0;
            this.passwordVisibleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.passwordVisibleBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.passwordVisibleBtn.Location = new System.Drawing.Point(230, 169);
            this.passwordVisibleBtn.Name = "passwordVisibleBtn";
            this.passwordVisibleBtn.Size = new System.Drawing.Size(103, 31);
            this.passwordVisibleBtn.TabIndex = 78;
            this.passwordVisibleBtn.Text = "Show";
            this.passwordVisibleBtn.UseVisualStyleBackColor = false;
            this.passwordVisibleBtn.Click += new System.EventHandler(this.button19_Click);
            // 
            // adminPasswordTxtBX
            // 
            this.adminPasswordTxtBX.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.adminPasswordTxtBX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.adminPasswordTxtBX.Location = new System.Drawing.Point(9, 169);
            this.adminPasswordTxtBX.Multiline = true;
            this.adminPasswordTxtBX.Name = "adminPasswordTxtBX";
            this.adminPasswordTxtBX.Size = new System.Drawing.Size(215, 31);
            this.adminPasswordTxtBX.TabIndex = 76;
            // 
            // adminLbl2
            // 
            this.adminLbl2.AutoSize = true;
            this.adminLbl2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.adminLbl2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.adminLbl2.Location = new System.Drawing.Point(9, 145);
            this.adminLbl2.Name = "adminLbl2";
            this.adminLbl2.Size = new System.Drawing.Size(159, 21);
            this.adminLbl2.TabIndex = 77;
            this.adminLbl2.Text = "Admin Password";
            this.adminLbl2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // adminLbl3
            // 
            this.adminLbl3.AutoSize = true;
            this.adminLbl3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.adminLbl3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.adminLbl3.Location = new System.Drawing.Point(9, 248);
            this.adminLbl3.Name = "adminLbl3";
            this.adminLbl3.Size = new System.Drawing.Size(144, 21);
            this.adminLbl3.TabIndex = 75;
            this.adminLbl3.Text = "Raw Spell Data";
            this.adminLbl3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rawDataTxtBx
            // 
            this.rawDataTxtBx.AcceptsReturn = true;
            this.rawDataTxtBx.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.rawDataTxtBx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rawDataTxtBx.Location = new System.Drawing.Point(9, 272);
            this.rawDataTxtBx.Multiline = true;
            this.rawDataTxtBx.Name = "rawDataTxtBx";
            this.rawDataTxtBx.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.rawDataTxtBx.Size = new System.Drawing.Size(469, 337);
            this.rawDataTxtBx.TabIndex = 74;
            // 
            // comitFileNameBtn
            // 
            this.comitFileNameBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.comitFileNameBtn.FlatAppearance.BorderSize = 0;
            this.comitFileNameBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comitFileNameBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.comitFileNameBtn.Location = new System.Drawing.Point(230, 101);
            this.comitFileNameBtn.Name = "comitFileNameBtn";
            this.comitFileNameBtn.Size = new System.Drawing.Size(103, 31);
            this.comitFileNameBtn.TabIndex = 73;
            this.comitFileNameBtn.Text = "Commit";
            this.comitFileNameBtn.UseVisualStyleBackColor = false;
            this.comitFileNameBtn.Click += new System.EventHandler(this.button18_Click);
            // 
            // fileNameTxtBx
            // 
            this.fileNameTxtBx.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.fileNameTxtBx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fileNameTxtBx.Location = new System.Drawing.Point(9, 101);
            this.fileNameTxtBx.Multiline = true;
            this.fileNameTxtBx.Name = "fileNameTxtBx";
            this.fileNameTxtBx.Size = new System.Drawing.Size(215, 31);
            this.fileNameTxtBx.TabIndex = 69;
            // 
            // adminLbl1
            // 
            this.adminLbl1.AutoSize = true;
            this.adminLbl1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.adminLbl1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.adminLbl1.Location = new System.Drawing.Point(9, 77);
            this.adminLbl1.Name = "adminLbl1";
            this.adminLbl1.Size = new System.Drawing.Size(133, 21);
            this.adminLbl1.TabIndex = 69;
            this.adminLbl1.Text = "Edit file Name";
            this.adminLbl1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(189, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 28);
            this.label13.TabIndex = 72;
            this.label13.Text = "Admin";
            // 
            // adminReturn
            // 
            this.adminReturn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.adminReturn.FlatAppearance.BorderSize = 0;
            this.adminReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminReturn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.adminReturn.Location = new System.Drawing.Point(378, 5);
            this.adminReturn.Name = "adminReturn";
            this.adminReturn.Size = new System.Drawing.Size(103, 48);
            this.adminReturn.TabIndex = 72;
            this.adminReturn.Text = "Return";
            this.adminReturn.UseVisualStyleBackColor = false;
            this.adminReturn.Click += new System.EventHandler(this.button13_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(199, 301);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 28);
            this.label1.TabIndex = 81;
            this.label1.Text = "Admin";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // menuPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1837, 593);
            this.Controls.Add(this.adminCheckPanel);
            this.Controls.Add(this.adminPanel);
            this.Controls.Add(this.spellPanel);
            this.Controls.Add(this.settingsPanel);
            this.Controls.Add(this.mediaPanel);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "menuPanel";
            this.ShowIcon = false;
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseLeave += new System.EventHandler(this.defaultLbl);
            ((System.ComponentModel.ISupportInitialize)(this.mediaBox)).EndInit();
            this.spellPanel.ResumeLayout(false);
            this.spellPanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.mediaPanel.ResumeLayout(false);
            this.settingsPanel.ResumeLayout(false);
            this.settingsPanel.PerformLayout();
            this.adminCheckPanel.ResumeLayout(false);
            this.adminCheckPanel.PerformLayout();
            this.adminPanel.ResumeLayout(false);
            this.adminPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label spellLbl1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox rangeBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox levelBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox compBox;
        private System.Windows.Forms.TextBox castingTimeBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Timer frameChange;
        private System.Windows.Forms.PictureBox mediaBox;
        private System.Windows.Forms.Button playBtn;
        private System.Windows.Forms.TextBox durationBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox schoolBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label spellLbl2;
        private System.Windows.Forms.Label splLbl3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button invertBtn;
        private System.Windows.Forms.Button reverseBtn;
        private System.Windows.Forms.Button pauseBtn;
        private System.Windows.Forms.Button BWbtn;
        private System.Windows.Forms.Button mediaReturnBtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button menuSpellBtn;
        private System.Windows.Forms.Button menuCharBtn;
        private System.Windows.Forms.Button menuSettingBtn;
        private System.Windows.Forms.Panel spellPanel;
        private System.Windows.Forms.Button menuMediaBtn;
        private System.Windows.Forms.Button menuExitBtn;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel mediaPanel;
        private System.Windows.Forms.Button menuAdminBtn;
        private System.Windows.Forms.Panel settingsPanel;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.RadioButton darkMode;
        private System.Windows.Forms.RadioButton lightMode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel adminCheckPanel;
        private System.Windows.Forms.Button adminCheckReturnBtn;
        private System.Windows.Forms.Button entrPswrdBtn;
        private System.Windows.Forms.TextBox adminPswrdInput;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel adminPanel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button adminReturn;
        private System.Windows.Forms.TextBox fileNameTxtBx;
        private System.Windows.Forms.Label adminLbl1;
        private System.Windows.Forms.Button comitFileNameBtn;
        private System.Windows.Forms.Label adminLbl3;
        private System.Windows.Forms.TextBox rawDataTxtBx;
        private System.Windows.Forms.Button updatePasswordBtn;
        private System.Windows.Forms.Button passwordVisibleBtn;
        private System.Windows.Forms.TextBox adminPasswordTxtBX;
        private System.Windows.Forms.Label adminLbl2;
        private System.Windows.Forms.Button saveRawBtn;
        private System.Windows.Forms.Label label1;
    }
}

