﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using System.DirectoryServices;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Reflection;


namespace test1
{
    public partial class menuPanel : Form
    {

        public Spell[] allSpells = new Spell[100]; //Main array of class spell objects
        public string[] allSpellSchools = new string[100]; //string arrays of that link to spells class
        public string[] allSpellName = new string[100];
        public string[] allSpellRange = new string[100];
        public string[] allSpellCastTime = new string[100];
        public string[] allSpellDuration = new string[100];
        public string[] allSpellComponent = new string[100];
        public string[] allSpellLevel = new string[100];

        public menuPanel()
        {
            InitializeComponent();
        }


        public class Spell //spell class variables
        {
            public string name;
            public string school;
            public string castingTime;
            public string range;
            public string duration;
            public string component;
            public string level;

        }

        public string adminPassword = "DND";
        public Spell[] filteredList = new Spell[100]; //spell array that stores the filtered list
        public string filter;

        public string[] School = {"Conjuration","Necromancy","Evocation","Abjuration","Transmutation",
                "Divination","Enchantment","Illusion"}; //set properties of spell classes to check
                                                        //against spell for filtering
        public string[] Level = { "Cantrip", "Level 1", "Level 2", "Level 3", "Level 4", "Level 5",
                "Level 6", "Level 7", "Level 8"};
        public string[] Components = { "V", "S", "M", "V,S,M", "V,S", "V,M", "S,M" };
        public string[] CastingTimes = { "Instantaneous", "Round(s)", "Minute(s)" };
        public string[] Duration = { "One Action", "Two Actions", "Three+ Actions" };
        public string[] Range = { "Input Distance", "In Feet", "Or Self", "eg. 60 Feet" };
        public bool filtered = false;

        public bool invert = false;
        public bool greyMode = false;
        public bool reverse = false;

        public string fileName = "spellData.txt";


        public class Character
        {
            /*
            string name;
            string race;
            int[] level;
            int overallLevel;
            string[] chrClass;
            int strength;
            int dexterity;
            int constitution;
            int intelligence;
            int wisdom;
            int charisma;
           
            */
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            


            string[] lines = System.IO.File.ReadAllLines(Directory.GetCurrentDirectory() + "/" + fileName);
            int index = 0; //gets the file from the given directory and stores each line as a string in an array


            foreach (string line in lines) //goes through each line in that file
            {

                string lineClone = line;
                string[] part = new string[10]; //a part represents an attribute of the spell
                Spell newSpell = new Spell(); //creates a new spell for each line
                int partIndex = 0;
                string divi = "_"; //the character that tells the program a new part is after
                int diviVal = 0;
                int priorDiviVal = 0;


                do //while do loop goes through each line in the file and formattes it into the spell array
                {

                    if (lineClone.Length > 0)
                    {
                        if (diviVal > 1)
                        {
                            part[partIndex] = lineClone.Substring(0, diviVal - 1); //check if at end of string
                        }
                        else
                        {
                            part[partIndex] = lineClone.Substring(0, diviVal);
                        }


                        lineClone = lineClone.Substring(diviVal, lineClone.Length - diviVal);
                        priorDiviVal = diviVal;
                        diviVal = lineClone.IndexOf(divi);
                        if (diviVal == -1) //if no new items are left in string

                        {
                            break;
                        }
                        else
                        {
                            diviVal += 1;
                        }
                        partIndex += 1;

                    }
                    else
                    {
                        break;
                    }
                } while (diviVal != -1);


                newSpell.name = part[1];
                allSpellName[index] = part[1];

                newSpell.range = part[4];
                allSpellRange[index] = part[4];

                newSpell.school = part[2];
                allSpellSchools[index] = part[2];

                newSpell.castingTime = part[5];
                allSpellCastTime[index] = part[5];

                newSpell.duration = part[3];
                allSpellDuration[index] = part[3];

                newSpell.component = part[6];
                allSpellComponent[index] = part[6];

                newSpell.level = lineClone;
                allSpellLevel[index] = lineClone;
                //assing spells and linked spell attributes


                allSpells[index] = newSpell; //assings new spell to spell array



                index += 1;

            }

            for (int i = 0; i < 30; i++)
            {
                allSpellName[i] = allSpells[i + 1].name;


            }

            string[] spellAttributes = new string[8];  //assigns spell attribute names
            spellAttributes[0] = "Name";
            spellAttributes[1] = "School";
            spellAttributes[2] = "Casting Time";
            spellAttributes[3] = "Duration";
            spellAttributes[4] = "Level";
            spellAttributes[5] = "Components";
            spellAttributes[6] = "Range";



            comboBox1.DataSource = allSpellName;
            comboBox2.DataSource = spellAttributes; //puts them 

        }

        public void discreteFilter(string filterString, string filterType) //filters list based on key
        {

            string[] tmpItem = new string[100]; //creates new temporary list

            int filteredListIndex = 0;
            Array.Clear(filteredList, 0, filteredList.Length); //clears current list

            if (filterType == "School") //checks what is being filtered
            {
                tmpItem = allSpellSchools;
            }
            else if (filterType == "Level")
            {
                tmpItem = allSpellLevel;
            }
            else if (filterType == "Range")
            {

                tmpItem = allSpellRange;
            }
            else if (filterType == "Components")
            {
                tmpItem = allSpellComponent;
            }
            else if (filterType == "Duration")
            {
                tmpItem = allSpellDuration;
                //needs refining
            }
            else if (filterType == "Casting Time")
            {
                tmpItem = allSpellCastTime;
                //needs refining
            }


            for (int i = 0; i < allSpells.Length; i++)
            {
                if (tmpItem[i] == filterString)
                {

                    filteredList[filteredListIndex] = allSpells[i];
                    filteredListIndex += 1; //assigns spells to filtered spell objects

                }
            }
            string[] filterListNames = new string[100];

            for (int i = 0; i < filteredListIndex; i++)
            {
                filterListNames[i] = filteredList[i].name;

            }

            if (filteredListIndex == 0)
            {


            }
            comboBox1.DataSource = filterListNames;
            filtered = true;

        }


        private void listItem(object sender, EventArgs e)
        {
            int i = 0;
            if (filtered is false)
            {
                i = comboBox1.SelectedIndex + 1; //lists item if no filter in place
                nameBox.Text = allSpells[i].name;
                rangeBox.Text = allSpells[i].range;
                levelBox.Text = allSpells[i].level;
                castingTimeBox.Text = allSpells[i].castingTime;
                schoolBox.Text = allSpells[i].school;
                compBox.Text = allSpells[i].component;
                durationBox.Text = allSpells[i].duration;
            }
            else
            {
                i = comboBox1.SelectedIndex; //lists item if filter is in place
                nameBox.Text = filteredList[i].name;
                rangeBox.Text = filteredList[i].range;
                levelBox.Text = filteredList[i].level;
                castingTimeBox.Text = filteredList[i].castingTime;
                schoolBox.Text = filteredList[i].school;
                compBox.Text = filteredList[i].component;
                durationBox.Text = filteredList[i].duration;
            }




        }
        public Label bloatedLbl = new Label();
        private void bloatLbl(object sender, EventArgs e) //resizes labels based on mouse hover trigger
        {
            bloatedLbl = sender as Label;
            bloatedLbl.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        }

        private void defaultLbl(object sender, EventArgs e) //reverts bloated label when mouse leaves
        {
            bloatedLbl.Font = new Font("Segoe UI", 10, FontStyle.Regular);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


        public int timerIndex = 0;
        private void changeFrame(object sender, EventArgs e)

        {
            mediaBox.Visible = true;

            if (timerIndex > 200 || timerIndex < 0)
            {
                frameChange.Enabled = false;
                mediaBox.Visible = false;
                timerIndex = 0;

            }
            if (reverse == false)
            {
                timerIndex += 1;
            }
            else
            {
                timerIndex -= 1;
            }

            string buffer1 = "00";

            if (timerIndex > 9)
            {
                if (timerIndex < 100)
                {
                    buffer1 = "0";
                }
                else
                {
                    buffer1 = "";

                }
            }

            string key = "ezgif_frame_" + buffer1 + timerIndex.ToString();

            ResourceManager rm = Properties.Resources.ResourceManager;


            Bitmap pic = (Bitmap)rm.GetObject(key);

            if (invert == true)
            {
                for (int y = 0; (y <= (pic.Height - 1)); y++)
                {
                    for (int x = 0; (x <= (pic.Width - 1)); x++)
                    {
                        Color inv = pic.GetPixel(x, y);
                        inv = Color.FromArgb(255, (255 - inv.R), (255 - inv.G), (255 - inv.B));
                        pic.SetPixel(x, y, inv);
                    }
                }
            }

            if (greyMode == true)
            {
                int rgb;
                Color c;

                for (int y = 0; y < pic.Height; y++)
                    for (int x = 0; x < pic.Width; x++)
                    {
                        c = pic.GetPixel(x, y);
                        rgb = (int)Math.Round(.299 * c.R + .587 * c.G + .114 * c.B);
                        pic.SetPixel(x, y, Color.FromArgb(rgb, rgb, rgb));
                    }
            }


            mediaBox.BackgroundImage = pic;
        }

        private void startMeme(object sender, EventArgs e)
        {
            timerIndex = 0;
            reverse = false;
            System.IO.Stream str = Properties.Resources.music;
            System.Media.SoundPlayer snd = new System.Media.SoundPlayer(str);
            snd.Play();
            frameChange.Enabled = true;
            mediaBox.Visible = true;




        }

        private void alterKey(object sender, EventArgs e)
        {

            if (comboBox2.Text != "")
            {
                if (comboBox2.Text == "Name") //lists key attributes that can be used to filter items
                {
                    comboBox3.DataSource = null;
                    comboBox1.DataSource = allSpellName;
                    filtered = false;
                    return;
                }
                else if (comboBox2.Text == "School")
                {
                    comboBox3.DataSource = School;

                }
                else if (comboBox2.Text == "Casting Time")
                {
                    comboBox3.DataSource = CastingTimes;

                }
                else if (comboBox2.Text == "Duration")
                {
                    comboBox3.DataSource = Duration;
                }
                else if (comboBox2.Text == "Range")
                {
                    comboBox3.DataSource = Range;
                }
                else if (comboBox2.Text == "Level")
                {
                    comboBox3.DataSource = Level;

                }
                else if (comboBox2.Text == "Components")
                {
                    comboBox3.DataSource = Components;

                }

                discreteFilter(comboBox3.Text, comboBox2.Text);
                filter = comboBox3.Text;

            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            invert = !invert;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            reverse = !invert;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frameChange.Enabled = !frameChange.Enabled;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            greyMode = !greyMode;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            spellPanel.Location = new Point(0, 0);
            spellPanel.BringToFront();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            mediaPanel.Location = new Point(0, 0); //moves current panel to the front to be viewed
            mediaPanel.BringToFront();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            settingsPanel.Location = new Point(0, 0);
            settingsPanel.BringToFront();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To Be Completed");
        }

        private void menuHighlight(object sender, EventArgs e)
        {
            Button curObject = sender as Button;   //gets button that called function
            if (curObject != null)
            {
                curObject.BackColor = SystemColors.MenuHighlight; //highlighted for hovered button
            }


        }

        private void revertHighlight(object sender, EventArgs e)
        {
            Button curObject = sender as Button;
            curObject.BackColor = SystemColors.ActiveCaption; //removes the highlight
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            panel2.BringToFront();
        }

        private void restartApp(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            adminCheckPanel.Location = new Point(((menuPanel.ActiveForm.Width / 2) - 80), (menuPanel.ActiveForm.Height / 2) - adminCheckPanel.Height);
            adminCheckPanel.BringToFront();
            fileNameTxtBx.Text = fileName;
            passwordVisibleBtn.Text = "Show"; //sets up admin panel for user
           

        }

        private void button16_Click(object sender, EventArgs e)
        {
            if(adminPswrdInput.Text == adminPassword)
            {
                adminPanel.BringToFront();
                adminPanel.Location = new Point(0,0);
                string[] lines = System.IO.File.ReadAllLines(Directory.GetCurrentDirectory() + "/" + fileName);
                foreach(string line in lines) { //gets each line from the given file and appends it onto a textbox
                    rawDataTxtBx.Text += line;
                }
                
            }
            else
            {
                adminPswrdInput.Text = "Incorrect";
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            fileName = fileNameTxtBx.Text;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Feature Not Yet Availible");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if(passwordVisibleBtn.Text == "Show")
            {
        
                adminPasswordTxtBX.Text = adminPassword; //presents the admin password when clicked
                passwordVisibleBtn.Text = "Hide";
            }
            else
            {
                passwordVisibleBtn.Text = "Show";
                string password = adminPasswordTxtBX.Text; //hides the code
                adminPasswordTxtBX.Text = "";
                    
                for(int i =0; i < password.Length; i++)
                {
                    adminPasswordTxtBX.Text += "*"; //finds the length of the password and replaces it with *'s 
                }
                    
                }
            }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            var controls = GetAll(this, typeof(Label));
            foreach (Control c in controls)  //takes all objects of the given type(label) and inverts the colours)
            {            
                c.ForeColor = Color.FromArgb(255 -c.ForeColor.R , 255 - c.ForeColor.G, 255 - c.ForeColor.B);
               
            }
            controls = GetAll(this, typeof(Button));
             foreach (Control c in controls)
            {          
                c.ForeColor = Color.FromArgb(255 -c.ForeColor.R , 255 - c.ForeColor.G, 255 - c.ForeColor.B);
               
            }
            controls = GetAll(this, typeof(Panel));
            foreach (Control c in controls)
            {
                c.ForeColor = Color.FromArgb(255 - c.ForeColor.R, 255 - c.ForeColor.G, 255 - c.ForeColor.B);
                c.BackColor = Color.FromArgb(255 - c.BackColor.R, 255 - c.BackColor.G, 255 - c.BackColor.B);
            }
            controls = GetAll(this, typeof(TextBox));
            foreach (Control c in controls)
            {
                c.ForeColor = Color.FromArgb(255 - c.ForeColor.R, 255 - c.ForeColor.G, 255 - c.ForeColor.B);
                c.BackColor = Color.FromArgb(255 - c.BackColor.R, 255 - c.BackColor.G, 255 - c.BackColor.B);
            }
             controls = GetAll(this, typeof(ComboBox));
            foreach (Control c in controls)
            {
               
                c.ForeColor = Color.FromArgb(255 - c.ForeColor.R, 255 - c.ForeColor.G, 255 - c.ForeColor.B);
                c.BackColor = Color.FromArgb(255 - c.BackColor.R, 255 - c.BackColor.G, 255 - c.BackColor.B);
            }
        }


        public IEnumerable<Control> GetAll(Control control, Type type) //takes a control and type 
        {
            var controller = control.Controls.Cast<Control>();  //finds all the objects in the from the control in (the form)

            return controller.SelectMany(ctrl => GetAll(ctrl, type)) //returns these objects
                              .Concat(controller)
                              .Where(c => c.GetType() == type);
}

        private void button21_Click(object sender, EventArgs e)
        {
            using (StreamWriter fileManager = new StreamWriter(Directory.GetCurrentDirectory() + "/" + fileName)) 
                //creates a stream writer for the given file
            {
               

                fileManager.Flush(); //wipes previous file
                fileManager.Write(rawDataTxtBx.Text); //appends new data    
                fileManager.Close(); 

                
            }
             
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

    }

    

