﻿
namespace test1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rangeBox = new System.Windows.Forms.TextBox();
            this.damageBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.levelBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.compBox = new System.Windows.Forms.TextBox();
            this.compValBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.upcastOffsetBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.targetBox = new System.Windows.Forms.TextBox();
            this.upcastTypeBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.upcastBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.saveTypeBox = new System.Windows.Forms.TextBox();
            this.saveBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.saveLbl = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.damageQuanBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.damageDiceBox = new System.Windows.Forms.TextBox();
            this.extraEffectRecipBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.extraEffectBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.compConsBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.descBox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.classesBox = new System.Windows.Forms.TextBox();
            this.ArcaneBox = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.saveEffectBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Spell";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 46);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(216, 33);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.TextUpdate += new System.EventHandler(this.listItem);
            this.comboBox1.TextChanged += new System.EventHandler(this.listItem);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(12, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(12, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Range";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(12, 127);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(215, 31);
            this.nameBox.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(277, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = "Damage";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rangeBox
            // 
            this.rangeBox.Location = new System.Drawing.Point(12, 266);
            this.rangeBox.Name = "rangeBox";
            this.rangeBox.Size = new System.Drawing.Size(216, 31);
            this.rangeBox.TabIndex = 6;
            // 
            // damageBox
            // 
            this.damageBox.Location = new System.Drawing.Point(277, 127);
            this.damageBox.Name = "damageBox";
            this.damageBox.Size = new System.Drawing.Size(180, 31);
            this.damageBox.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(12, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Level";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // levelBox
            // 
            this.levelBox.Location = new System.Drawing.Point(12, 195);
            this.levelBox.Name = "levelBox";
            this.levelBox.Size = new System.Drawing.Size(214, 31);
            this.levelBox.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(12, 442);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Component(s)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // compBox
            // 
            this.compBox.Location = new System.Drawing.Point(12, 470);
            this.compBox.Name = "compBox";
            this.compBox.Size = new System.Drawing.Size(214, 31);
            this.compBox.TabIndex = 11;
            // 
            // compValBox
            // 
            this.compValBox.Location = new System.Drawing.Point(12, 532);
            this.compValBox.Name = "compValBox";
            this.compValBox.Size = new System.Drawing.Size(215, 31);
            this.compValBox.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(12, 504);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(215, 25);
            this.label7.TabIndex = 20;
            this.label7.Text = "Component Gold Value(s)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // upcastOffsetBox
            // 
            this.upcastOffsetBox.Location = new System.Drawing.Point(274, 594);
            this.upcastOffsetBox.Name = "upcastOffsetBox";
            this.upcastOffsetBox.Size = new System.Drawing.Size(183, 31);
            this.upcastOffsetBox.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Location = new System.Drawing.Point(274, 566);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 25);
            this.label8.TabIndex = 18;
            this.label8.Text = "Upcast Offset";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // targetBox
            // 
            this.targetBox.Location = new System.Drawing.Point(12, 328);
            this.targetBox.Name = "targetBox";
            this.targetBox.Size = new System.Drawing.Size(214, 31);
            this.targetBox.TabIndex = 17;
            // 
            // upcastTypeBox
            // 
            this.upcastTypeBox.Location = new System.Drawing.Point(274, 532);
            this.upcastTypeBox.Name = "upcastTypeBox";
            this.upcastTypeBox.Size = new System.Drawing.Size(183, 31);
            this.upcastTypeBox.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Location = new System.Drawing.Point(12, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 25);
            this.label9.TabIndex = 15;
            this.label9.Text = "Target Area";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // upcastBox
            // 
            this.upcastBox.Location = new System.Drawing.Point(274, 470);
            this.upcastBox.Name = "upcastBox";
            this.upcastBox.Size = new System.Drawing.Size(183, 31);
            this.upcastBox.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Location = new System.Drawing.Point(274, 504);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "Upcast Type";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Location = new System.Drawing.Point(274, 442);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 25);
            this.label11.TabIndex = 12;
            this.label11.Text = "Upcast";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // saveTypeBox
            // 
            this.saveTypeBox.Location = new System.Drawing.Point(488, 532);
            this.saveTypeBox.Name = "saveTypeBox";
            this.saveTypeBox.Size = new System.Drawing.Size(161, 31);
            this.saveTypeBox.TabIndex = 25;
            // 
            // saveBox
            // 
            this.saveBox.Location = new System.Drawing.Point(488, 470);
            this.saveBox.Name = "saveBox";
            this.saveBox.Size = new System.Drawing.Size(161, 31);
            this.saveBox.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Location = new System.Drawing.Point(488, 504);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 25);
            this.label13.TabIndex = 23;
            this.label13.Text = "Save Type";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // saveLbl
            // 
            this.saveLbl.AutoSize = true;
            this.saveLbl.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.saveLbl.Location = new System.Drawing.Point(488, 442);
            this.saveLbl.Name = "saveLbl";
            this.saveLbl.Size = new System.Drawing.Size(49, 25);
            this.saveLbl.TabIndex = 22;
            this.saveLbl.Text = "Save";
            this.saveLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Location = new System.Drawing.Point(277, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 25);
            this.label12.TabIndex = 26;
            this.label12.Text = "Damage Quantity";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // damageQuanBox
            // 
            this.damageQuanBox.Location = new System.Drawing.Point(275, 195);
            this.damageQuanBox.Name = "damageQuanBox";
            this.damageQuanBox.Size = new System.Drawing.Size(182, 31);
            this.damageQuanBox.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label15.Location = new System.Drawing.Point(275, 229);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(160, 25);
            this.label15.TabIndex = 28;
            this.label15.Text = "Rolls Damage Dice";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // damageDiceBox
            // 
            this.damageDiceBox.Location = new System.Drawing.Point(277, 257);
            this.damageDiceBox.Name = "damageDiceBox";
            this.damageDiceBox.Size = new System.Drawing.Size(180, 31);
            this.damageDiceBox.TabIndex = 29;
            // 
            // extraEffectRecipBox
            // 
            this.extraEffectRecipBox.Location = new System.Drawing.Point(488, 195);
            this.extraEffectRecipBox.Name = "extraEffectRecipBox";
            this.extraEffectRecipBox.Size = new System.Drawing.Size(161, 31);
            this.extraEffectRecipBox.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label16.Location = new System.Drawing.Point(488, 167);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 25);
            this.label16.TabIndex = 32;
            this.label16.Text = "Effect Recip";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // extraEffectBox
            // 
            this.extraEffectBox.Location = new System.Drawing.Point(488, 127);
            this.extraEffectBox.Name = "extraEffectBox";
            this.extraEffectBox.Size = new System.Drawing.Size(161, 31);
            this.extraEffectBox.TabIndex = 31;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label17.Location = new System.Drawing.Point(488, 99);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 25);
            this.label17.TabIndex = 30;
            this.label17.Text = "Extra Effect";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label18.Location = new System.Drawing.Point(10, 566);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(216, 25);
            this.label18.TabIndex = 34;
            this.label18.Text = "Component(s) Consumed";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // compConsBox
            // 
            this.compConsBox.Location = new System.Drawing.Point(12, 594);
            this.compConsBox.Name = "compConsBox";
            this.compConsBox.Size = new System.Drawing.Size(215, 31);
            this.compConsBox.TabIndex = 35;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label19.Location = new System.Drawing.Point(681, 99);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(102, 25);
            this.label19.TabIndex = 36;
            this.label19.Text = "Description";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // descBox
            // 
            this.descBox.Location = new System.Drawing.Point(681, 127);
            this.descBox.Multiline = true;
            this.descBox.Name = "descBox";
            this.descBox.Size = new System.Drawing.Size(241, 232);
            this.descBox.TabIndex = 37;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label20.Location = new System.Drawing.Point(681, 442);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 25);
            this.label20.TabIndex = 38;
            this.label20.Text = "Classes";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // classesBox
            // 
            this.classesBox.Location = new System.Drawing.Point(681, 470);
            this.classesBox.Multiline = true;
            this.classesBox.Name = "classesBox";
            this.classesBox.Size = new System.Drawing.Size(241, 217);
            this.classesBox.TabIndex = 39;
            this.classesBox.Text = "TBD";
            // 
            // ArcaneBox
            // 
            this.ArcaneBox.AutoSize = true;
            this.ArcaneBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ArcaneBox.Location = new System.Drawing.Point(12, 628);
            this.ArcaneBox.Name = "ArcaneBox";
            this.ArcaneBox.Size = new System.Drawing.Size(117, 25);
            this.ArcaneBox.TabIndex = 40;
            this.ArcaneBox.Text = "Arcane Focus";
            this.ArcaneBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(13, 656);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(215, 31);
            this.textBox20.TabIndex = 41;
            this.textBox20.Text = "no fookin clue";
            // 
            // saveEffectBox
            // 
            this.saveEffectBox.Location = new System.Drawing.Point(488, 594);
            this.saveEffectBox.Name = "saveEffectBox";
            this.saveEffectBox.Size = new System.Drawing.Size(161, 31);
            this.saveEffectBox.TabIndex = 43;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label14.Location = new System.Drawing.Point(488, 566);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 25);
            this.label14.TabIndex = 42;
            this.label14.Text = "Save Effect";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 738);
            this.Controls.Add(this.saveEffectBox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.ArcaneBox);
            this.Controls.Add(this.classesBox);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.descBox);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.compConsBox);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.extraEffectRecipBox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.extraEffectBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.damageDiceBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.damageQuanBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.saveTypeBox);
            this.Controls.Add(this.saveBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.saveLbl);
            this.Controls.Add(this.compValBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.upcastOffsetBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.targetBox);
            this.Controls.Add(this.upcastTypeBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.upcastBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.compBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.levelBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.damageBox);
            this.Controls.Add(this.rangeBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Spell Info";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox rangeBox;
        private System.Windows.Forms.TextBox damageBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox levelBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox compBox;
        private System.Windows.Forms.TextBox compValBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox upcastOffsetBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox targetBox;
        private System.Windows.Forms.TextBox upcastTypeBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox upcastBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox saveTypeBox;
        private System.Windows.Forms.TextBox saveBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label saveLbl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox damageQuanBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox damageDiceBox;
        private System.Windows.Forms.TextBox extraEffectRecipBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox extraEffectBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox compConsBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox descBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox classesBox;
        private System.Windows.Forms.Label ArcaneBox;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox saveEffectBox;
        private System.Windows.Forms.Label label14;
    }
}

