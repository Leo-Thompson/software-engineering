﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Form1 : Form
    {

        public Spell[] allSpells = new Spell[5];
        public Form1()
        {
            InitializeComponent();
        }


        public class Spell
        {
            public int level;
            public string name;
            public string desc;
            public bool upcast;
            public string upcastType;
            public int upcastOffset;
            public bool save;
            public string saveCat;
            public bool playerSave;
            public bool savePass;
            public bool saveEffect;
            public bool spellDamage;
            public int spellDamageVal;
            public bool rollDamageDice;
            public bool extraEffect;
            public string effectRecip;
            public int range;
            public string targetArea;
            public string[] classes;
            public bool[] componenets = new bool[2];
            public int[] componentGoldVal = new int[2];
            public bool[] componentConsumed = new bool[2];
            public bool componentArcanceFocus;
            public bool attackRoll;

         

        }

        public class Character
        {
            /*
            string name;
            string race;
            int[] level;
            int overallLevel;
            string[] chrClass;
            int strength;
            int dexterity;
            int constitution;
            int intelligence;
            int wisdom;
            int charisma;
           
            */
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            

            

            Spell defaultSpell = new Spell();
            defaultSpell.level = 0;
            defaultSpell.name = "Default";
            defaultSpell.desc = "A default spell";
            defaultSpell.range = 0;
            defaultSpell.upcast = false;
            defaultSpell.save = false;
            defaultSpell.extraEffect = false;
            defaultSpell.spellDamage = false;
            defaultSpell.targetArea = "Self";
            defaultSpell.componenets = new[] { true, true, true };
            defaultSpell.componentGoldVal = new[] { 0, 50, 20 };
            defaultSpell.componentArcanceFocus = false;
            defaultSpell.attackRoll = false;
            

            Spell fireSpell = new Spell();
            fireSpell.level = 3;
            fireSpell.name = "Fireball";
            fireSpell.desc = "A fireball";
            fireSpell.range = 4;
            fireSpell.upcast = false;
            fireSpell.save = false;
            fireSpell.extraEffect = false;
            fireSpell.spellDamage = true;
            fireSpell.spellDamageVal = 20;
            fireSpell.targetArea = "5ft Radius";
            fireSpell.componenets = new[] { false, false, true };
            fireSpell.componentGoldVal = new[] { 0, 0, 20 };
            fireSpell.componentArcanceFocus = false;
            fireSpell.attackRoll = false;
            

            Spell waterSpell = new Spell();
            waterSpell.level = 2;
            waterSpell.name = "Water Cannon";
            waterSpell.desc = "wa er";
            waterSpell.range = 2;
            waterSpell.upcast = false;
            waterSpell.save = false;
            waterSpell.extraEffect = false;
            waterSpell.spellDamage = true;
            waterSpell.spellDamageVal = 10;
            waterSpell.targetArea = "30ft Radius";
            waterSpell.componenets = new[] { false, true, true };
            waterSpell.componentGoldVal = new[] { 0, 20, 30 };
            waterSpell.componentArcanceFocus = false;
            waterSpell.attackRoll = false;
            

            Spell earthSpell = new Spell();
            earthSpell.level = 4;
            earthSpell.name = "Earthquake";
            earthSpell.desc = "makes ground jiggle";
            earthSpell.range = 7;
            earthSpell.upcast = false;
            earthSpell.save = false;
            earthSpell.extraEffect = false;
            earthSpell.spellDamage = false;
            earthSpell.targetArea = "50ft Radius";
            earthSpell.componenets = new[] { true, false, true };
            earthSpell.componentGoldVal = new[] { 20, 0, 10 };
            earthSpell.componentArcanceFocus = false;
            earthSpell.attackRoll = false;

            Spell healSpell = new Spell();
            healSpell.level = 3;
            healSpell.name = "Self-Heal";
            healSpell.desc = "heals lost HP";
            healSpell.range = 1;
            healSpell.upcast = false;
            healSpell.save = false;
            healSpell.extraEffect = true;
            healSpell.effectRecip = "Self";
            healSpell.spellDamage = false;
            healSpell.targetArea = "Self";
            healSpell.componenets = new[] { true, true, true };
            healSpell.componentGoldVal = new[] { 20, 0, 0 };
            healSpell.componentArcanceFocus = false;
            healSpell.attackRoll = false;

            allSpells[0] = defaultSpell;
            allSpells[1] = waterSpell;
            allSpells[2] = fireSpell;
            allSpells[3] = earthSpell;
            allSpells[4] = healSpell;
           

            string[] spellName = new string[5];          
            for (int i = 0; i < spellName.Length; i++)
            {
                spellName[i] = allSpells[i].name;
            }    
            comboBox1.DataSource = spellName;
        }

        private void listItem(object sender, EventArgs e)
        {
            int i = comboBox1.SelectedIndex;
            nameBox.Text = allSpells[i].name;
            rangeBox.Text = allSpells[i].range.ToString();        
            levelBox.Text = allSpells[i].level.ToString();
            descBox.Text = allSpells[i].desc;
            targetBox.Text = allSpells[i].targetArea;

            if (allSpells[i].upcast == true)
            {
                upcastOffsetBox.Text = allSpells[i].upcastOffset.ToString();
                upcastTypeBox.Text = allSpells[i].upcastType;
            }
            else
            {
                upcastBox.Text = "None";
            }

            
            compBox.Text = "";
            compValBox.Text = "";
            if (allSpells[i].componenets[0] == true)
            {
                compBox.Text += "V";
                compValBox.Text += allSpells[i].componentGoldVal[0].ToString() + ",";
            }

            if (allSpells[i].componenets[1] == true)
            {
                compBox.Text += "S";
                compValBox.Text += allSpells[i].componentGoldVal[1].ToString() + ",";
            }
            if (allSpells[i].componenets[2] == true)
            {
                compBox.Text += "M";
                compValBox.Text += allSpells[i].componentGoldVal[2].ToString();

            }

            if(allSpells[i].spellDamage == true)
            {
                damageBox.Text = "Does Damage";
                damageQuanBox.Text = allSpells[i].spellDamageVal.ToString();

                if(allSpells[i].rollDamageDice == true)
                {
                    damageDiceBox.Text = "On";
                }
                else
                {
                    damageDiceBox.Text = "Off";
                }
            }
            else
            {
                damageBox.Text = "Doesn't Damage";
                damageQuanBox.Text = "N/A";
                damageDiceBox.Text = "N/A";
            }

            if(allSpells[i].extraEffect == true)
            {
                extraEffectBox.Text = "Yes";
                extraEffectRecipBox.Text = allSpells[i].effectRecip = "Self";
            }
            else
            {
                extraEffectBox.Text = "No";
                extraEffectRecipBox.Text = "N/A";
            }

            if(allSpells[i].save == true)
            {
                saveBox.Text = "Yes";
                saveTypeBox.Text = allSpells[i].saveCat;
                saveEffectBox.Text = allSpells[i].saveEffect.ToString();
            }
            else
            {
                saveBox.Text = "No";
                saveTypeBox.Text = "N/A";
                saveEffectBox.Text = "N/A";
            }







        }
    }
}
