﻿
namespace test1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.rangeBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.levelBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.compBox = new System.Windows.Forms.TextBox();
            this.castingTimeBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.frameChange = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.durationBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.schoolBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Spell";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label1.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 46);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(245, 33);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.TextUpdate += new System.EventHandler(this.listItem);
            this.comboBox1.TextChanged += new System.EventHandler(this.listItem);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(12, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label2.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(12, 363);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Range";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label3.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label3.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(13, 143);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(215, 31);
            this.nameBox.TabIndex = 4;
            // 
            // rangeBox
            // 
            this.rangeBox.Location = new System.Drawing.Point(12, 391);
            this.rangeBox.Name = "rangeBox";
            this.rangeBox.Size = new System.Drawing.Size(216, 31);
            this.rangeBox.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(12, 301);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Level";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label5.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label5.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // levelBox
            // 
            this.levelBox.Location = new System.Drawing.Point(12, 329);
            this.levelBox.Name = "levelBox";
            this.levelBox.Size = new System.Drawing.Size(214, 31);
            this.levelBox.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(12, 487);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Component(s)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label6.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label6.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // compBox
            // 
            this.compBox.Location = new System.Drawing.Point(12, 515);
            this.compBox.Name = "compBox";
            this.compBox.Size = new System.Drawing.Size(214, 31);
            this.compBox.TabIndex = 11;
            // 
            // castingTimeBox
            // 
            this.castingTimeBox.Location = new System.Drawing.Point(12, 267);
            this.castingTimeBox.Name = "castingTimeBox";
            this.castingTimeBox.Size = new System.Drawing.Size(214, 31);
            this.castingTimeBox.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Location = new System.Drawing.Point(12, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 25);
            this.label9.TabIndex = 15;
            this.label9.Text = "Casting Time";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label9.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label9.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // frameChange
            // 
            this.frameChange.Interval = 50;
            this.frameChange.Tick += new System.EventHandler(this.changeFrame);
            // 
            // pictureBox1
            // 
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(267, 312);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(499, 315);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Tomato;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(267, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 30);
            this.button1.TabIndex = 45;
            this.button1.Text = "Don\'t Click";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.startMeme);
            // 
            // durationBox
            // 
            this.durationBox.Location = new System.Drawing.Point(12, 453);
            this.durationBox.Name = "durationBox";
            this.durationBox.Size = new System.Drawing.Size(214, 31);
            this.durationBox.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label21.Location = new System.Drawing.Point(12, 425);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(81, 25);
            this.label21.TabIndex = 47;
            this.label21.Text = "Duration";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label21.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label21.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // schoolBox
            // 
            this.schoolBox.Location = new System.Drawing.Point(12, 205);
            this.schoolBox.Name = "schoolBox";
            this.schoolBox.Size = new System.Drawing.Size(214, 31);
            this.schoolBox.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(12, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 25);
            this.label4.TabIndex = 48;
            this.label4.Text = "School";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label4.MouseLeave += new System.EventHandler(this.defaultLbl);
            this.label4.MouseHover += new System.EventHandler(this.bloatLbl);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(364, 141);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(215, 33);
            this.comboBox2.TabIndex = 50;
            this.comboBox2.TextUpdate += new System.EventHandler(this.alterKey);
            this.comboBox2.TextChanged += new System.EventHandler(this.alterKey);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label7.Location = new System.Drawing.Point(364, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 51;
            this.label7.Text = "Filter By";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label8.Location = new System.Drawing.Point(364, 177);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 25);
            this.label8.TabIndex = 52;
            this.label8.Text = "Key";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(364, 205);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(215, 33);
            this.comboBox3.TabIndex = 53;
            this.comboBox3.TextUpdate += new System.EventHandler(this.alterKey);
            this.comboBox3.TextChanged += new System.EventHandler(this.alterKey);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 738);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.schoolBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.durationBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.castingTimeBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.compBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.levelBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.rangeBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseLeave += new System.EventHandler(this.defaultLbl);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox rangeBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox levelBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox compBox;
        private System.Windows.Forms.TextBox castingTimeBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Timer frameChange;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox durationBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox schoolBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox3;
    }
}

