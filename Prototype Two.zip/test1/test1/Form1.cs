﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using System.DirectoryServices;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Reflection;

namespace test1
{
    public partial class Form1 : Form
    {

        public Spell[] allSpells = new Spell[100];
        public Form1()
        {
            InitializeComponent();
        }


        public class Spell
        {
            public string name;
            public string school;
            public string castingTime;
            public string range;
            public string duration;
            public string component;
            public string level;

        }

        public string filter;
    
        public string[] School = {"Conjuration","Necromancy","Evocation","Abjuration","Transmutation",
                "Divination","Enchantment","Illusion"};
        public string[] Level = { "Cantrip", "Level 1", "Level 2", "Level 3", "Level 4", "Level 5",
                "Level 6", "Level 7", "Level 8"};
        public string[] Components = { "V", "S", "M", "V,S,M", "V,S", "V,M", "S,M" };
        public string[] CastingTimes = { "Instantaneous", "Round(s)", "Minute(s)" };
        public string[] Duration = { "One Action", "Two Actions", "Three+ Actions" };
        public string[] Range = { "Self", "15-30ft", "31-60ft", "60+ft" };
        string[] spellName = new string[30];



        public class Character
        {
            /*
            string name;
            string race;
            int[] level;
            int overallLevel;
            string[] chrClass;
            int strength;
            int dexterity;
            int constitution;
            int intelligence;
            int wisdom;
            int charisma;
           
            */
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            string[] lines = System.IO.File.ReadAllLines(Directory.GetCurrentDirectory() + "/spellData.txt");
            int index = 0;



            foreach (string line in lines)
            {
                
                string lineClone = line;
                string[] part = new string[10];
                Spell newSpell = new Spell();
                int partIndex = 0;
                string divi = "_";
                int diviVal = 0;
                int priorDiviVal = 0;
                

                do
                {

                    if (lineClone.Length > 0)
                    {
                        if(diviVal > 1)
                        {
                            part[partIndex] = lineClone.Substring(0, diviVal - 1);
                        }
                        else
                        {
                            part[partIndex] = lineClone.Substring(0, diviVal);
                        }

                       
                        lineClone = lineClone.Substring(diviVal, lineClone.Length - diviVal);                     
                        priorDiviVal = diviVal;
                        diviVal = lineClone.IndexOf(divi);
                        if (diviVal == -1)

                        {
                            break;
                        }
                        else
                        {
                            diviVal += 1;
                        }
                        partIndex += 1;                   
                        
                    }
                    else
                    {                                       
                        break;
                    }                                
                } while (diviVal != -1);
               

                newSpell.name = part[1];
                newSpell.range = part[4];
                newSpell.school = part[2];
                newSpell.castingTime = part[5];
                newSpell.duration = part[3];
                newSpell.component = part[6];
                newSpell.level = lineClone;
                


                allSpells[index] = newSpell;



                index += 1;

                }

          

             
            for (int i = 0; i < 30; i++)
            {         
                spellName[i] = allSpells[i + 1].name;
               
               
            }

            string[] spellAttributes = new string[8];
            spellAttributes[0] = "Name";
            spellAttributes[1] = "School";
            spellAttributes[2] = "Casting Time";
            spellAttributes[3] = "Duration";
            spellAttributes[4] = "Level";
            spellAttributes[5] = "Components";
            spellAttributes[6] = "Range";

            
            
            comboBox1.DataSource = spellName;
                              
            comboBox2.DataSource = spellAttributes;
          
        }

        public void discreteFilter(string filterString)
        {
           
            comboBox1.Text = "";
            int newItemIndex = 0;
            string[] filteredList = new string[30];
            for (int i = 0; i < allSpells.Length; i++)
            {
                if (allSpells[i] != null)
                {

                    if (allSpells[i].school == filterString)
                    {
                        filteredList[newItemIndex] = allSpells[i].name;
                        newItemIndex += 1;
                      
                    }
                }
               
            }
            comboBox1.DataSource = filteredList;
        }
    

        private void listItem(object sender, EventArgs e)
        {
       
            int i = comboBox1.SelectedIndex + 1;
            nameBox.Text = allSpells[i].name;
            rangeBox.Text = allSpells[i].range;        
            levelBox.Text = allSpells[i].level;     
            castingTimeBox.Text = allSpells[i].castingTime;
            schoolBox.Text = allSpells[i].school;
            compBox.Text = allSpells[i].component;
            durationBox.Text = allSpells[i].duration;
           

        }
        public Label bloatedLbl = new Label();
        private void bloatLbl(object sender, EventArgs e)
        {
            bloatedLbl = sender as Label;
            bloatedLbl.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        }

        private void defaultLbl(object sender, EventArgs e)
        {        
            bloatedLbl.Font = new Font("Segoe UI", 10, FontStyle.Regular);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


        public int timerIndex = 0;
        private void changeFrame(object sender, EventArgs e)

        {
            pictureBox1.Visible = true;

            if(timerIndex > 200)
            {
                frameChange.Enabled = false;
                pictureBox1.Visible = false;

            }
            timerIndex += 1;
            string buffer1 = "00";

            if(timerIndex > 9)
            {
                if (timerIndex < 100)
                {
                    buffer1 = "0";
                }
                else
                {
                    buffer1 = "";

                }
            }
            
            string key = "ezgif_frame_" + buffer1 + timerIndex.ToString();

            ResourceManager rm = Properties.Resources.ResourceManager;
            Bitmap curImg = (Bitmap)rm.GetObject(key);
       
            pictureBox1.BackgroundImage = curImg;
        }

        private void startMeme(object sender, EventArgs e)
        {

            System.IO.Stream str = Properties.Resources.music;
            System.Media.SoundPlayer snd = new System.Media.SoundPlayer(str);
            snd.Play();
            frameChange.Enabled = true;
            pictureBox1.Visible = true;
            timerIndex = 0;
            

        }

        private void alterKey(object sender, EventArgs e)
        {
           
            if(comboBox2.Text != "") {
               if(comboBox2.Text == "Name")
                {
                    comboBox1.DataSource = spellName;
                   
                }
               else if(comboBox2.Text == "School")
                {
                    comboBox3.DataSource = School;
                    discreteFilter(comboBox3.Text);

                }
                else if (comboBox2.Text == "Casting Time")
                {
                    comboBox3.DataSource = CastingTimes;

                }
                else if (comboBox2.Text == "Duration")
                {
                    comboBox3.DataSource = Duration;
                }
                else if (comboBox2.Text == "Range")
                {
                    comboBox3.DataSource = Range;
                }
                else if (comboBox2.Text == "Level")
                {
                    comboBox3.DataSource = Level;
                    discreteFilter(comboBox3.Text);
                }
                else if (comboBox2.Text == "Components")
                {
                    comboBox3.DataSource = Components;
                    discreteFilter(comboBox3.Text);
                }
                filter = comboBox3.Text;

            }
           
            

        }
            
        }
    }

