﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using System.DirectoryServices;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Reflection;


namespace test1
{
    public partial class menuPanel : Form
    {

       
        public menuPanel()
        {
            InitializeComponent();
        }


        
        public string adminPassword = "DND";
   
        public string filter;


        public string fileName = "spellData.txt";


     
        private void Form1_Load(object sender, EventArgs e)
        {

            


        }

      
        public Label bloatedLbl = new Label();
        private void bloatLbl(object sender, EventArgs e) //resizes labels based on mouse hover trigger
        {
            bloatedLbl = sender as Label;
            bloatedLbl.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        }

        private void defaultLbl(object sender, EventArgs e) //reverts bloated label when mouse leaves
        {
            bloatedLbl.Font = new Font("Segoe UI", 10, FontStyle.Regular);
        }

    
       
        private void button8_Click(object sender, EventArgs e)
        {
            this.Width *= 2;
            spellPanel.Location = new Point(0, 0);
            spellPanel.BringToFront();

        }

        private void button10_Click(object sender, EventArgs e)
        {
            settingsPanel.Location = new Point(0, 0);
            settingsPanel.BringToFront();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Width *= 2;
            charPanel.Location = new Point(0, 0);
            charPanel.BringToFront();
        }

        private void menuHighlight(object sender, EventArgs e)
        {
            Button curObject = sender as Button;   //gets button that called function
            if (curObject != null)
            {
                curObject.BackColor = SystemColors.MenuHighlight; //highlighted for hovered button 
            }


        }
        private void revertHighlight(object sender, EventArgs e)
        {
            Button curObject = sender as Button;
            curObject.BackColor = SystemColors.ActiveCaption; //removes the highlight
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Width = 507;
            panel2.BringToFront(); //makes a specific panel the one the user can see
        }

       

        private void button7_Click(object sender, EventArgs e)
        {
            adminCheckPanel.Location = new Point(((menuPanel.ActiveForm.Width / 2) - 80), (menuPanel.ActiveForm.Height / 2) - adminCheckPanel.Height);
            adminCheckPanel.BringToFront();
            fileNameTxtBx.Text = fileName;
            passwordVisibleBtn.Text = "Show"; //sets up admin panel for user
           

        }

        private void button16_Click(object sender, EventArgs e)
        {
            if(adminPswrdInput.Text == adminPassword)
            {
                adminPanel.BringToFront();
                adminPanel.Location = new Point(0,0);
                string[] lines = System.IO.File.ReadAllLines(Directory.GetCurrentDirectory() + "/" + fileName);
                foreach(string line in lines) { //gets each line from the given file and appends it onto a textbox
                    rawDataTxtBx.Text += line;
                }
                
            }
            else
            {
                adminPswrdInput.Text = "Incorrect";
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            fileName = fileNameTxtBx.Text;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Feature Not Yet Availible");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if(passwordVisibleBtn.Text == "Show")
            {
        
                adminPasswordTxtBX.Text = adminPassword; //presents the admin password when clicked
                passwordVisibleBtn.Text = "Hide";
            }
            else
            {
                passwordVisibleBtn.Text = "Show";
                string password = adminPasswordTxtBX.Text; //hides the code
                adminPasswordTxtBX.Text = "";
                    
                for(int i =0; i < password.Length; i++)
                {
                    adminPasswordTxtBX.Text += "*"; //finds the length of the password and replaces it with *'s 
                }
                    
                }
            }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            var controls = GetAll(this, typeof(Label));
            foreach (Control c in controls)  //takes all objects of the given type(label) and inverts the colours)
            {            
                c.ForeColor = Color.FromArgb(255 -c.ForeColor.R , 255 - c.ForeColor.G, 255 - c.ForeColor.B);
               
            }
            controls = GetAll(this, typeof(Button));
             foreach (Control c in controls)
            {          
                c.ForeColor = Color.FromArgb(255 -c.ForeColor.R , 255 - c.ForeColor.G, 255 - c.ForeColor.B);
               
            }
            controls = GetAll(this, typeof(Panel));
            foreach (Control c in controls)
            {
                c.ForeColor = Color.FromArgb(255 - c.ForeColor.R, 255 - c.ForeColor.G, 255 - c.ForeColor.B);
                c.BackColor = Color.FromArgb(255 - c.BackColor.R, 255 - c.BackColor.G, 255 - c.BackColor.B);
            }
            controls = GetAll(this, typeof(TextBox));
            foreach (Control c in controls)
            {
                c.ForeColor = Color.FromArgb(255 - c.ForeColor.R, 255 - c.ForeColor.G, 255 - c.ForeColor.B);
                c.BackColor = Color.FromArgb(255 - c.BackColor.R, 255 - c.BackColor.G, 255 - c.BackColor.B);
            }
             controls = GetAll(this, typeof(ComboBox));
            foreach (Control c in controls)
            {
               
                c.ForeColor = Color.FromArgb(255 - c.ForeColor.R, 255 - c.ForeColor.G, 255 - c.ForeColor.B);
                c.BackColor = Color.FromArgb(255 - c.BackColor.R, 255 - c.BackColor.G, 255 - c.BackColor.B);
            }
        }


        public IEnumerable<Control> GetAll(Control control, Type type) //takes a control and type 
        {
            var controller = control.Controls.Cast<Control>();  //finds all the objects in the from the control in (the form)

            return controller.SelectMany(ctrl => GetAll(ctrl, type)) //returns these objects
                              .Concat(controller)
                              .Where(c => c.GetType() == type);
}

        private void button21_Click(object sender, EventArgs e)
        {
            using (StreamWriter fileManager = new StreamWriter(Directory.GetCurrentDirectory() + "/" + fileName)) 
                //creates a stream writer for the given file
            {
               

                fileManager.Flush(); //wipes previous file
                fileManager.Write(rawDataTxtBx.Text); //appends new data    
                fileManager.Close(); 

                
            }                   
        }
        public int getRandomInt(int min, int max)
        {
            Random random = new Random();
            int number = random.Next(min, max + 1);
            
            return number;

        }

    

        private void newTick(object sender, EventArgs e)
        {
            int rnd1 = getRandomInt(0, 3);
            int rnd2 = getRandomInt(0, 3);
            int rnd3 = getRandomInt(0, 3);

            if(getRandomInt(1, 2) == 2)
            {
                rnd1 = -rnd1;
            }
            if (getRandomInt(1, 2) == 2)
            {
                rnd2 = -rnd2;
            }

            if (getRandomInt(1, 2) == 2)
            {
                rnd3 = -rnd3;
            }

            if (panel2.BackColor.R + rnd1 > 0 && panel2.BackColor.R + rnd1 < 255 &&
                panel2.BackColor.G + rnd2 > 0 && panel2.BackColor.G + rnd2 < 255 &&
                panel2.BackColor.B + rnd3 > 0 && panel2.BackColor.B + rnd3 < 255)
            {
                panel2.BackColor = Color.FromArgb(panel2.BackColor.R + rnd1, panel2.BackColor.G + rnd2, panel2.BackColor.B + rnd3);
            }

           
        }
    }

    }

    

